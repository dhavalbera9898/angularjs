<?php $__env->startSection('title','Add User'); ?>
<?php $__env->startSection('content'); ?>

hiii


<?php echo $__env->make('layout.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>