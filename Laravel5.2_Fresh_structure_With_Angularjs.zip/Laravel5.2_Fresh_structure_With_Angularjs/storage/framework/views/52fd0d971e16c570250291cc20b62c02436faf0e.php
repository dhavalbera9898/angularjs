<!DOCTYPE html>
<html lang="en" > <!-- ng-app="myApp" -->
<head>
        
 
    <title> <?php echo $__env->yieldContent('title','Home'); ?> | <?php echo e(config('app.projectName')); ?></title>

    <!--  Set here External CSS -->
    
    <?php echo $__env->yieldContent('css'); ?>

    <script type="text/javascript">window.baseUrl = "<?php echo URL::to('/')?>";</script>
    <script type="text/javascript">window.basePath = "<?php echo base_path(); ?>";</script>
    <script src="<?php echo e(URL::asset('resources/assets/js/angularjs/angular.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('resources/assets/js/angularjs/app.js')); ?>"></script>

  
    <!--  Set here External JS -->
    
    
    <script src="<?php echo e(URL::asset('resources/assets/js/jquery.validate.min.js')); ?>"></script>
    
    
    <script src="<?php echo e(URL::asset('resources/assets/js/angularjs/dirPagination.js')); ?>"></script>

    <script type="text/javascript" src="<?php echo asset('resources/assets/js/angularjs/angular-loading-spinner.js'); ?>"></script>
    <script type="text/javascript" src="<?php echo asset('resources/assets/js/angularjs/angular-spinner.js'); ?>"></script>
    <script type="text/javascript" src="<?php echo asset('resources/assets/js/angularjs/spin.js'); ?>"></script>
    <script type="text/javascript" src="<?php echo e(URL::asset('resources/assets/js/toastr.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(URL::asset('resources/assets/js/common.js')); ?>"></script>
    

    <?php echo $__env->yieldContent('script'); ?>

 
</head>
<span data-us-spinner="{radius:30, width:8, length: 16,scale:0.5}" class="loading-ui-block"> </span>

    
<body>

<!-- Main navbar -->

            <?php echo $__env->yieldContent('content'); ?>

<!-- Main End -->
    

<!-- Footer -->
         <div class="footer text-muted" style="margin-left: 2%;">
             &copy; <?php echo e(date('Y')); ?>. <?php echo e(config('app.projectName')); ?>

         </div>
<!-- /footer -->


</body>
</html>
