<footer class="main-footer">
    <div class="container">
        <p class="text-muted pull-left">
            LogViewer - <span class="label label-info">version <?php echo e(log_viewer()->version()); ?></span>
        </p>
        <p class="text-muted pull-right">
            Created with <i class="fa fa-heart"></i> by ARCANEDEV <sup>&copy;</sup>
        </p>
    </div>
</footer>
