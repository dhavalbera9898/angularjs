<section class="content-header">
    <?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        <ul>
            <?php foreach($errors->all() as $error): ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>


    <?php if(Session::has('error')): ?>
    <div class="alert alert-danger msg_display">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <?php echo e(Session::get('error')); ?>

    </div>
    <?php endif; ?>
    <?php if(Session::has('success')): ?>
    <div class="alert alert-success msg_display">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <?php echo e(Session::get('success')); ?>

    </div>
    <?php endif; ?>

    <?php if(Session::has('info')): ?>
    <div class="alert alert-info msg_display">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <?php echo e(Session::get('info')); ?>

    </div>
    <?php endif; ?>  
</section>