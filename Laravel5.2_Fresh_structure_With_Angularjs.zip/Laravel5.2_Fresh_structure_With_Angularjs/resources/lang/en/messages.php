<?php
return array(

    "NoResult"=>"Sorry, no results were found",
    "Refine"=>"",
    "updateSuccessMessage"=>"Your record have been successfully updated.",
    "addSuccessMessage"=>"Your record have been successfully added.",
    "deleteSuccessMessage"=>"Your Record have been successfully deleted.",
    "invalidCredentials"=>"Invalid Credentials.",
 
);
