<!DOCTYPE html>
<html lang="en" > <!-- ng-app="myApp" -->
<head>
        
 
    <title> @yield('title','Home') | {{config('app.projectName')}}</title>

    <!--  Set here External CSS -->
    
    @yield('css')

    <script type="text/javascript">window.baseUrl = "<?php echo URL::to('/')?>";</script>
    <script type="text/javascript">window.basePath = "<?php echo base_path(); ?>";</script>
    <script src="{{ URL::asset('resources/assets/js/angularjs/angular.js')}}"></script>
    <script src="{{ URL::asset('resources/assets/js/angularjs/app.js')}}"></script>

  
    <!--  Set here External JS -->
    
    
    <script src="{{ URL::asset('resources/assets/js/jquery.validate.min.js') }}"></script>
    
    
    <script src="{{URL::asset('resources/assets/js/angularjs/dirPagination.js')}}"></script>

    <script type="text/javascript" src="<?php echo asset('resources/assets/js/angularjs/angular-loading-spinner.js'); ?>"></script>
    <script type="text/javascript" src="<?php echo asset('resources/assets/js/angularjs/angular-spinner.js'); ?>"></script>
    <script type="text/javascript" src="<?php echo asset('resources/assets/js/angularjs/spin.js'); ?>"></script>
    <script type="text/javascript" src="{{ URL::asset('resources/assets/js/toastr.js') }}"></script>
    <script type="text/javascript" src="{{ URL::asset('resources/assets/js/common.js') }}"></script>
    

    @yield('script')

 
</head>
<span data-us-spinner="{radius:30, width:8, length: 16,scale:0.5}" class="loading-ui-block"> </span>

    
<body>

<!-- Main navbar -->

            @yield('content')

<!-- Main End -->
    

<!-- Footer -->
         <div class="footer text-muted" style="margin-left: 2%;">
             &copy; {{date('Y')}}. {{config('app.projectName')}}
         </div>
<!-- /footer -->


</body>
</html>
