@extends('layout.master')
    @section('title','Add User')
@section('content')

hiii


@include('layout.messages') 





@endsection
