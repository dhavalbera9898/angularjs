var app = angular.module('myApp', ["ngLoadingSpinner","angularUtils.directives.dirPagination"]);

app.config(function(paginationTemplateProvider){
    paginationTemplateProvider.setPath(window.baseUrl + '/dirPagination'); // Set dir-pagination blade or html file path
});




