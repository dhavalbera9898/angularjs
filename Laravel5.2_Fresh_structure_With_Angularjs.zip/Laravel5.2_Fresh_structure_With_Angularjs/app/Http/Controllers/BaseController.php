<?php
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use View;
use App\web\NotificationModel;
use App\web\UserModel;


class BaseController extends Controller
{
    public function __construct(){    
       
        
    }
}