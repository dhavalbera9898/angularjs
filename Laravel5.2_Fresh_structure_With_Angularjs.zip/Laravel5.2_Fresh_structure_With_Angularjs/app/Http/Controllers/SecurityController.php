<?php

namespace App\Http\Controllers;

use App\Infrastructure\Constants;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Session;
use view;
use DB;
use Illuminate\Support\Facades\Input;
use Validator;
use App\web\CityModel;
use App\ViewModels\ServiceResponse;
use stdClass;



class SecurityController extends BaseController{
    
    public function getPagination() {
        return view('dirPagination');
    }
    
    public function index(){
            return view('index');
    }
  
}
