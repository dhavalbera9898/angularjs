<?php
namespace App\ViewModels;

class ServiceRequest {
	public $Token;
	public $Data;
	
}
