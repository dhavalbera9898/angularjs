<?php
namespace App\ViewModels;

class ServiceResponse {
	public $IsSuccess;
	public $Data;
	public $Message;
	public $ErrorCode;

	public function __construct($IsSuccess = false){
		$this->IsSuccess = $IsSuccess;
	}
}
