<?php
namespace App\Infrastructure;

class Constants{
    
    public static $Value_True = 1;
    public static $Value_False = 0;
    public static $isDeleteTrue = 1;
    public static $isDeleteFalse = 0;
    public static $Status_Active = 1;
    public static $Status_InActive = 0;
   
    public static $SortIndex = 'id';
    public static $SortIndexASC = 'ASC';
    public static $SortIndexDESC = 'DESC';
    public static $TotalItemsCountColumn = "TotalItemsCount";
    public static $PageIndex = 'PageIndex';
    
    public static $displayDateFormatForAll = 'd-m-Y';
    public static $displayDateTimeFormatForAll = 'd-m-Y H:i:s';
    public static $DefaultDateTimeFormat = 'Y-m-d H:i:s';
    public static $dateFormatForDisplayDate = 'mm/dd/yyyy';
    public static $displayDateFormat = 'yyyy-MM-dd';    
    
  
}
