<?php

namespace App\Infrastructure;
use Illuminate\Support\Facades\DB;

class Common{
    
		public static function ipaddress(){
			return '192.168.10.10';
		}
        
        public static  function filesize_formatted($size){
            $units = array( 'B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB');
            $power = $size > 0 ? floor(log($size, 1024)) : 0;
            return number_format($size / pow(1024, $power), 2, '.', ',') . ' ' . $units[$power];
        }
        
        public static function GetCsvFromArray($array){
            $csv = "";
            for ($i = 0; $i < count($array); $i++) {
                $csv .= str_replace('"', '""', $array[$i]->id);
                if ($i < count($array) - 1) $csv .= ",";
            }
            return $csv;
        }
        
        
}
