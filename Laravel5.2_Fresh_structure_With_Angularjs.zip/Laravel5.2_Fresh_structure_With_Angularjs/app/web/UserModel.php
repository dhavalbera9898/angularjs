<?php

namespace App\web;

use App\Infrastructure\Common;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Datatables;
use App\Infrastructure\Constants;
use stdClass;
use Illuminate\Support\Facades\Input;
use Illuminate\Http\Request;
use File;
use session;
use Log,Mail;

class UserModel extends Model {

    protected $table = 'user';
    
    /*public static function getCurrentUserDetails(){
       return $user = UserModel::find(Session::get('User_id'));
    }*/
    
    

}
